export type Category = "COSMOS" | "NATURE" | "SHADOW" | "SPIRIT";
export type Card = {
  id: string; number: number; category: Category; name: string; cat: string;
  symbol: string; meaning: string; light: string; shadow: string;
  love: string; career: string; finance: string; advice: string;
};

const seeds: Array<[string,string,string,string,string]> = [
 ["The Sun Cat","Cream longhair","sunflower","Joy returns when you make room for it.","Choose the simple thing that makes you feel alive."],
 ["The Moon Cat","Black shorthair","crescent moon","Not everything needs an immediate answer.","Listen carefully, but check assumptions."],
 ["The Star Cat","Silver tabby","crystal star","Hope grows through small, steady actions.","Take one gentle step toward what inspires you."],
 ["The Hermit Cat","Ginger cat","lantern","Quiet time can reveal what noise hides.","Give yourself space before deciding."],
 ["The Eclipse","Tuxedo cat","eclipse","A pause can change the way you see a situation.","Look at the same problem from a new angle."],
 ["The Wildflower","Calico cat","flower","Growth rarely follows a straight line.","Let a small experiment surprise you."],
 ["The Tidekeeper","Blue-grey cat","wave","Feelings move; you do not have to move with every wave.","Wait for the emotional tide to settle."],
 ["The Keybearer","Maine Coon","antique key","A useful opening may come from asking a better question.","Notice the option you have overlooked."],
 ["The Mirror","White-and-grey cat","mirror","Honest reflection creates room for change.","Name what is yours to change."],
 ["The Lantern","Golden tabby","lantern","A little clarity is enough for the next step.","Focus on the next step, not the whole road."],
 ["The Phoenix Paw","Ruddy cat","flame","A setback can become material for renewal.","Keep the lesson; release the self-blame."],
 ["The Guardian","Fluffy tortoiseshell","shield","Boundaries can protect what matters.","Say a kind, clear no when you need to."]
];

const categories: Category[] = ["COSMOS","NATURE","SHADOW","SPIRIT"];
const extras: Array<[string,string,string,string,string]> = [
 ["The Comet","Siamese cat","comet","A brief opportunity may deserve your attention.","Act thoughtfully while the window is open."],
 ["The Orbit","Bengal cat","orbit","Patterns become visible when you step back.","Notice what keeps repeating."],
 ["The Dawn","Lilac-point cat","dawn","A fresh beginning can be quiet.","Start before you feel perfectly ready."],
 ["The Constellation","Tabby kitten","stars","Your connections can form a bigger picture.","Ask for perspective from someone you trust."],
 ["The Rootkeeper","Brown tabby","roots","Stability is built through ordinary care.","Return to the habit that supports you."],
 ["The Rainmaker","Blue cat","raindrop","Release can make space for renewal.","Let one unnecessary thing go."],
 ["The Moss Witch","Forest-green-eyed cat","moss","Patience is an active form of care.","Give a slow-growing plan time."],
 ["The Seed","Tiny black kitten","seed","A small idea can become something meaningful.","Protect your new idea while it is still tender."],
 ["The Veil","Smoke-grey cat","veil","Some details are not ready to be clear.","Separate facts from guesses."],
 ["The Mask","Calico cat","mask","You may be performing a role that no longer fits.","Choose honesty over pleasing everyone."],
 ["The Raven","Black Maine Coon","raven","A difficult message can still be useful.","Listen for the information beneath the tone."],
 ["The Threshold","White cat","doorway","You are between an old chapter and a new one.","Decide what you want to carry forward."],
 ["The Heartflame","Ginger kitten","heart","Warmth grows when it is shared freely.","Offer care without abandoning your needs."],
 ["The Muse","Cream Persian","quill","Inspiration often arrives while you are making.","Begin imperfectly and keep moving."],
 ["The Dancer","Tuxedo cat","ribbon","Flexibility can be stronger than control.","Try a different approach."],
 ["The Voyager","Siberian cat","compass","Curiosity points toward useful discoveries.","Explore without demanding instant certainty."],
 ["The Alchemist","Silver cat","crucible","You can transform what you have already learned.","Combine two skills in a new way."],
 ["The Bell","Golden kitten","bell","A signal deserves your attention.","Pause and notice what is asking to be heard."],
 ["The Weaver","Longhair tabby","thread","Small choices connect into a larger story.","Make the next choice with intention."],
 ["The Hearth","Ragdoll cat","candle","Comfort is a resource, not a reward.","Create a place where you can recharge."],
 ["The Owlcat","Brown spotted cat","owl","Wisdom includes knowing what you do not know.","Ask before assuming."],
 ["The Bridge","Black-and-white cat","bridge","A conversation may connect two distant views.","Look for shared ground."],
 ["The Compass Rose","Calico kitten","compass rose","Your values can guide a confusing choice.","Choose what aligns with your priorities."],
 ["The Pearl","White fluffy cat","pearl","Something valuable may be forming quietly.","Do not rush a process that needs time."],
 ["The Storm","Dark grey cat","storm cloud","Strong emotions are signals, not instructions.","Ground yourself before responding."],
 ["The Feather","Cream kitten","feather","Lightness can come from simplifying.","Remove one thing from your to-do list."],
 ["The Hourglass","Silver tabby","hourglass","Time is a resource to spend deliberately.","Give your attention to what matters today."],
 ["The Gardener","Tortoiseshell cat","watering can","Careful consistency creates growth.","Do one small maintenance task."],
 ["The Flamekeeper","Black cat with amber eyes","candle flame","Your energy needs tending.","Protect time for what restores you."],
 ["The Messenger","Siamese kitten","envelope","A clear message can prevent confusion.","Say what you mean with kindness."],
 ["The Mountain","Large grey cat","mountain","Progress may be slower than you hoped, but real.","Break the challenge into manageable parts."],
 ["The Dreamer","Blue-eyed white cat","cloud","Imagination can reveal a possibility.","Write down the idea before it fades."],
 ["The Circle","Two bonded cats","golden ring","Support is built through mutual care.","Reach out and make space for connection."]
];

export const cards: Card[] = [...seeds, ...extras].map((s, i) => {
  const category = categories[Math.floor(i / 12)];
  return {
    id: `cat-${String(i+1).padStart(2,"0")}`, number:i+1, category,
    name:s[0], cat:s[1], symbol:s[2], meaning:s[3], light:s[3], shadow:"Be careful not to turn this message into a certainty. Notice where fear or haste may be shaping your interpretation.",
    love:"Make room for honest communication, mutual respect and clear boundaries.",
    career:"Focus on one practical next step rather than trying to solve everything at once.",
    finance:"Review the facts and make measured choices; this card is not financial advice.",
    advice:s[4]
  };
});
