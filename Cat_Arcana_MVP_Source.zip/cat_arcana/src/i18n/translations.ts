export type Lang = "en" | "uk" | "es" | "fr" | "de" | "pt-BR" | "ja";
export const languages: {code:Lang; label:string; flag:string}[] = [
 {code:"en",label:"English",flag:"🇬🇧"},{code:"uk",label:"Українська",flag:"🇺🇦"},
 {code:"es",label:"Español",flag:"🇪🇸"},{code:"fr",label:"Français",flag:"🇫🇷"},
 {code:"de",label:"Deutsch",flag:"🇩🇪"},{code:"pt-BR",label:"Português (Brasil)",flag:"🇧🇷"},
 {code:"ja",label:"日本語",flag:"🇯🇵"}
];
const en = {
 tagline:"A little magic, one paw at a time",daily:"YOUR CARD OF THE DAY",draw:"DRAW MY CARD",
 ask:"ASK THE UNIVERSE",collection:"MY COLLECTION",journal:"JOURNAL",profile:"PROFILE",
 choose:"Choose a card and listen to its story.",today:"Today's message",advice:"YOUR PAW-SITIVE ADVICE",
 save:"SAVE TO JOURNAL",saved:"Saved to your journal",question:"What is on your mind?",
 placeholder:"Write your question…",topic:"Choose a theme",general:"General",love:"Love",career:"Career",money:"Money",growth:"Personal growth",
 one:"One card",three:"Three cards",reveal:"REVEAL CARDS",situation:"Situation",hidden:"Hidden influence",direction:"Suggested direction",
 all:"All cards",favorites:"Favorites",language:"Language",settings:"Settings",about:"About Cat Arcana",
 note:"Your note (optional)",empty:"Your readings will appear here.",disclaimer:"For entertainment and personal reflection only. Cards do not predict guaranteed outcomes.",
 back:"BACK",meaning:"Meaning",light:"Light",shadow:"Shadow",share:"Share",newReading:"NEW READING",premium:"PREMIUM",
 noCard:"You have already drawn today's card. Come back tomorrow for a new one."
};
const dict: Record<Lang, typeof en> = {
 en,
 uk:{tagline:"Трохи магії — у кожній лапці",daily:"ТВОЯ КАРТА ДНЯ",draw:"ВИТЯГНУТИ КАРТУ",ask:"ЗАПИТАТИ ВСЕСВІТ",collection:"МОЯ КОЛЕКЦІЯ",journal:"ЩОДЕННИК",profile:"ПРОФІЛЬ",choose:"Обери карту та почуй її історію.",today:"Послання дня",advice:"ТВОЯ ПОРАДА",save:"ЗБЕРЕГТИ В ЩОДЕННИК",saved:"Збережено в щоденнику",question:"Що тебе турбує?",placeholder:"Напиши своє запитання…",topic:"Обери тему",general:"Загальне",love:"Кохання",career:"Кар'єра",money:"Фінанси",growth:"Саморозвиток",one:"Одна карта",three:"Три карти",reveal:"ВІДКРИТИ КАРТИ",situation:"Ситуація",hidden:"Прихований вплив",direction:"Можливий напрямок",all:"Усі карти",favorites:"Обране",language:"Мова",settings:"Налаштування",about:"Про Cat Arcana",note:"Твоя нотатка (необов'язково)",empty:"Тут з'являтимуться твої розклади.",disclaimer:"Для розваги та особистих роздумів. Карти не гарантують передбачення.",back:"НАЗАД",meaning:"Значення",light:"Світла сторона",shadow:"Тіньова сторона",share:"Поділитися",newReading:"НОВИЙ РОЗКЛАД",premium:"PREMIUM",noCard:"Ти вже витягнула карту сьогодні. Повертайся завтра."
 },
 es:{...en,tagline:"Un poco de magia, paso a paso",daily:"TU CARTA DEL DÍA",draw:"SACAR MI CARTA",ask:"PREGUNTA AL UNIVERSO",collection:"MI COLECCIÓN",journal:"DIARIO",profile:"PERFIL",today:"Mensaje de hoy",advice:"TU CONSEJO",save:"GUARDAR EN EL DIARIO",saved:"Guardado en tu diario",question:"¿Qué tienes en mente?",placeholder:"Escribe tu pregunta…",topic:"Elige un tema",general:"General",love:"Amor",career:"Trabajo",money:"Dinero",growth:"Crecimiento personal",one:"Una carta",three:"Tres cartas",reveal:"REVELAR CARTAS",language:"Idioma",empty:"Tus lecturas aparecerán aquí.",disclaimer:"Solo para entretenimiento y reflexión personal."},
 fr:{...en,tagline:"Un peu de magie, patte après patte",daily:"TA CARTE DU JOUR",draw:"TIRER MA CARTE",ask:"INTERROGER L’UNIVERS",collection:"MA COLLECTION",journal:"JOURNAL",profile:"PROFIL",today:"Message du jour",advice:"TON CONSEIL",save:"ENREGISTRER",saved:"Enregistré dans ton journal",question:"À quoi penses-tu ?",placeholder:"Écris ta question…",topic:"Choisir un thème",general:"Général",love:"Amour",career:"Carrière",money:"Argent",growth:"Développement personnel",one:"Une carte",three:"Trois cartes",reveal:"RÉVÉLER",language:"Langue",empty:"Tes tirages apparaîtront ici.",disclaimer:"Pour le divertissement et la réflexion personnelle uniquement."},
 de:{...en,tagline:"Ein bisschen Magie, Pfote für Pfote",daily:"DEINE TAGESKARTE",draw:"MEINE KARTE ZIEHEN",ask:"FRAGE DAS UNIVERSUM",collection:"MEINE SAMMLUNG",journal:"TAGEBUCH",profile:"PROFIL",today:"Botschaft des Tages",advice:"DEIN RAT",save:"IM TAGEBUCH SPEICHERN",saved:"Im Tagebuch gespeichert",question:"Was beschäftigt dich?",placeholder:"Schreibe deine Frage…",topic:"Thema wählen",general:"Allgemein",love:"Liebe",career:"Karriere",money:"Finanzen",growth:"Persönliche Entwicklung",one:"Eine Karte",three:"Drei Karten",reveal:"KARTEN AUFDECKEN",language:"Sprache",empty:"Deine Legungen erscheinen hier.",disclaimer:"Nur zur Unterhaltung und persönlichen Reflexion."},
 "pt-BR":{...en,tagline:"Um pouco de magia, uma patinha por vez",daily:"SUA CARTA DO DIA",draw:"TIRAR MINHA CARTA",ask:"PERGUNTE AO UNIVERSO",collection:"MINHA COLEÇÃO",journal:"DIÁRIO",profile:"PERFIL",today:"Mensagem de hoje",advice:"SEU CONSELHO",save:"SALVAR NO DIÁRIO",saved:"Salvo no seu diário",question:"O que está pensando?",placeholder:"Escreva sua pergunta…",topic:"Escolha um tema",general:"Geral",love:"Amor",career:"Carreira",money:"Dinheiro",growth:"Crescimento pessoal",one:"Uma carta",three:"Três cartas",reveal:"REVELAR CARTAS",language:"Idioma",empty:"Suas leituras aparecerão aqui.",disclaimer:"Apenas para entretenimento e reflexão pessoal."},
 ja:{...en,tagline:"一歩ずつ、少しの魔法を",daily:"今日のカード",draw:"カードを引く",ask:"宇宙にたずねる",collection:"マイコレクション",journal:"ジャーナル",profile:"プロフィール",today:"今日のメッセージ",advice:"今日のアドバイス",save:"ジャーナルに保存",saved:"保存しました",question:"何が気になっていますか？",placeholder:"質問を書いてください…",topic:"テーマを選ぶ",general:"全般",love:"恋愛",career:"仕事",money:"お金",growth:"自己成長",one:"1枚",three:"3枚",reveal:"カードを公開",language:"言語",empty:"ここにリーディングが表示されます。",disclaimer:"娯楽と自己理解のためのものです。未来を保証するものではありません。"}
};
export function t(lang:Lang,key:keyof typeof en):string { return dict[lang]?.[key] ?? en[key]; }
